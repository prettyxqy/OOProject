package com.app.demo.fragments;


import android.content.DialogInterface;
import android.os.Bundle;
import android.service.autofill.Dataset;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.fragment.app.Fragment;

import com.app.demo.R;
import com.app.demo.activitys.AddRemindActivity;
import com.app.demo.activitys.LoginActivity;
import com.app.demo.activitys.SelfActivity;
import com.app.demo.activitys.SetActivity;
import com.app.demo.beans.OrderBean;
import com.app.demo.beans.RemindBean;
import com.app.shop.mylibrary.base.BaseFragment;
import com.app.shop.mylibrary.beans.EventMessage;
import com.app.shop.mylibrary.utils.DialogUtil;
import com.app.shop.mylibrary.utils.SharedPreferencesUtil;
import com.app.shop.mylibrary.utils.TimeUtil;
import com.app.shop.mylibrary.utils.UserManager;
import com.app.shop.mylibrary.widgts.CustomDialog;
import com.app.shop.mylibrary.widgts.ExperienceProgress;
import com.facebook.drawee.view.SimpleDraweeView;

import org.litepal.crud.DataSupport;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;

/**
 * A simple {@link Fragment} subclass.
 */
public class MineFragment extends BaseFragment {


    @BindView(R.id.tv_username_mine)
    TextView tvUsernameMine;
    @BindView(R.id.imgv_face)
    SimpleDraweeView imgvFace;
    @BindView(R.id.progress_level)
    ExperienceProgress progressLevel;
    @BindView(R.id.tv_days)
    TextView tvDays;
    @BindView(R.id.tv_remind)
    TextView tvRemind;


    private String dialog_title = "退出登录";
    private String dialog_content = "是否确定退出登录？";
    private CustomDialog customDialog;

    RemindBean bean;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_mine, container, false);
        ButterKnife.bind(this, view);
        registerEventBus();
        setSelfView();
        return view;
    }

    private void setSelfView() {
        tvUsernameMine.setText(UserManager.getUserName(getActivity()));
        imgvFace.setActualImageResource(UserManager.getPhoto(getActivity()));

        String today = TimeUtil.getTodayData("yyyy-MM-dd");
        List<OrderBean> list = DataSupport.findAll(OrderBean.class);
        String date = null;

        if (list.size() > 0) {
            OrderBean bean = list.get(0);
            date = bean.getTime();
        } else {
            date = today;
        }


        SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd");
        Date firstDate = null;
        Date secondDate = null;
        try {
            firstDate = df.parse(date);
            secondDate = df.parse(today);
        } catch (Exception e) {
            // 日期型字符串格式错误
            System.out.println("日期型字符串格式错误");
        }
        int nDay = (int) ((secondDate.getTime() - firstDate.getTime()) / (24 * 60 * 60 * 1000)) + 1;

        int progress = (int) ((nDay * 1.0f / 14) * 100);
        progressLevel.setProgress(progress);

        tvDays.setText("已经坚持记账（" + nDay + "/14）天");

        List<RemindBean> list1 = DataSupport.findAll(RemindBean.class);
        for (int i = 0; i < list1.size(); i++) {
            if (list1.get(i).getUser_id().equals(UserManager.getUserId(getActivity()))) {
                bean = list1.get(i);
            }
        }
        if (bean != null) {
            tvRemind.setText(bean.getTime() + "(" + bean.getPinlv() + ")");
        } else {
            tvRemind.setText("添加提醒");
        }
    }


    @Override
    public void onEvent(EventMessage msg) {
        super.onEvent(msg);

        if (msg.getMessageType() == EventMessage.Refresh) {
            setSelfView();
        }
    }

    @OnClick({R.id.rela_self, R.id.rela_order, R.id.rela_set, R.id.rela_logout})
    public void onViewClicked(View view) {
        switch (view.getId()) {
            case R.id.rela_self:
                skipActivity(getActivity(), SelfActivity.class);
                break;
            case R.id.rela_order:
                Bundle bundle = new Bundle();
                bundle.putSerializable("bean", bean);
                skipActivity(getActivity(), AddRemindActivity.class, bundle);
                break;

            case R.id.rela_set:
                skipActivity(getActivity(), SetActivity.class);
                break;
            case R.id.rela_logout:
                Logout();
                break;
        }
    }

    private void Logout() {
        customDialog = DialogUtil.showDialog(getActivity(), customDialog, 2, dialog_title, dialog_content, "取消", "确定", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        }, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
                SharedPreferencesUtil.removeAll(getContext(), "user");
                skipActivity(getActivity(), LoginActivity.class);
                getActivity().finish();
            }
        });

        if (customDialog != null && !customDialog.isShowing()) {
            customDialog.show();
        }

        customDialog.setOnDismissListener(new DialogInterface.OnDismissListener() {
            @Override
            public void onDismiss(DialogInterface dialog) {
                customDialog = null;
            }
        });
    }
}
