package com.app.demo.beans;

import org.litepal.crud.DataSupport;

import java.io.Serializable;

public class LineBean extends DataSupport implements Serializable {

    private int id;

    private String name;
    private int num;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getNum() {
        return num;
    }

    public void setNum(int num) {
        this.num = num;
    }
}
