package com.app.demo.activitys;

import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.WindowManager;
import android.widget.PopupWindow;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.viewpager.widget.ViewPager;

import com.app.demo.R;
import com.app.demo.beans.OrderBean;
import com.app.demo.beans.PriceBean;
import com.app.shop.mylibrary.base.BaseActivity;
import com.app.shop.mylibrary.beans.EventMessage;
import com.app.shop.mylibrary.utils.TimeUtil;
import com.app.shop.mylibrary.utils.ToastUtil;
import com.app.shop.mylibrary.utils.UserManager;

import org.litepal.crud.DataSupport;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;

public class SelfActivity extends BaseActivity implements View.OnClickListener {

    @BindView(R.id.tv_title)
    TextView tvTitle;
    @BindView(R.id.tv_num)
    TextView tvNum;
    @BindView(R.id.tv_num_year)
    TextView tvNumYear;
    @BindView(R.id.tv_num_month)
    TextView tvNumMonth;
    @BindView(R.id.tv_day_out)
    TextView tvDayOut;
    @BindView(R.id.tv_month_out)
    TextView tvMonthOut;
    @BindView(R.id.ll_container)
    RelativeLayout llContainer;

    PopupWindow popupWindow;
    int clickPosition = 0;
    @BindView(R.id.view_shadow)
    View viewShadow;
    PriceBean bean;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_self);
        ButterKnife.bind(this);
        tvTitle.setText("我的钱包");

        initData();

    }

    private void initPop(int position) {
        if (popupWindow == null) {
            View view = LayoutInflater.from(this).inflate(R.layout.layout_pop, null);
            popupWindow = new PopupWindow(view, ViewPager.LayoutParams.MATCH_PARENT, ViewPager.LayoutParams.WRAP_CONTENT);

            TextView tv_1 = view.findViewById(R.id.tv_1);
            TextView tv_2 = view.findViewById(R.id.tv_2);
            TextView tv_3 = view.findViewById(R.id.tv_3);

            if (position == 0) {
                tv_1.setTextColor(getResources().getColor(R.color.color_666666));
            } else {
                tv_1.setTextColor(getResources().getColor(R.color.color_43496A));
            }


            tv_1.setOnClickListener(this);
            tv_2.setOnClickListener(this);
            tv_3.setOnClickListener(this);

            // 设置背景
            popupWindow.setBackgroundDrawable(new ColorDrawable());
            // 外部点击事件
            popupWindow.setOutsideTouchable(true);

            popupWindow.setOnDismissListener(new PopupWindow.OnDismissListener() {
                @Override
                public void onDismiss() {
                    popupWindow = null;
                    viewShadow.setVisibility(View.GONE);
                }
            });
        }
    }

    private void initData() {

        List<PriceBean> list = DataSupport.findAll(PriceBean.class);
        for (int i = 0; i < list.size(); i++) {
            if (list.get(i).getUser_id().equals(UserManager.getUserId(this))) {
                bean = list.get(i);
            }
        }

        if (bean != null) {
            tvNumYear.setText(bean.getYear());
            tvNumMonth.setText(bean.getMonth());
        }

        List<OrderBean> list_order = DataSupport.findAll(OrderBean.class);
        List<OrderBean> list_today = new ArrayList<>();
        List<OrderBean> list_month = new ArrayList<>();

        String today = TimeUtil.getTodayData("yyyy-MM-dd");
        String month = TimeUtil.getTodayData("yyyy-MM");

        for (int i = 0; i < list_order.size(); i++) {
            if (list_order.get(i).getTime().equals(today) && list_order.get(i).getType().equals("支出")) {
                list_today.add(list_order.get(i));
            }
            if (list_order.get(i).getTime().contains(month) && list_order.get(i).getType().equals("支出")) {
                list_month.add(list_order.get(i));
            }
        }

        int total_day = 0;
        int total_month = 0;
        for (int i = 0; i < list_today.size(); i++) {
            int num = Integer.parseInt(list_today.get(i).getMoney());
            total_day += num;
        }
        for (int i = 0; i < list_month.size(); i++) {
            int num = Integer.parseInt(list_today.get(i).getMoney());
            total_month += num;
        }
        tvDayOut.setText(total_day + "");
        tvMonthOut.setText(total_month + "");
    }


    @Override
    public void onEvent(EventMessage msg) {
        super.onEvent(msg);
        if (msg.getMessageType() == EventMessage.Refresh) {

        }
    }


    @OnClick({R.id.imgv_return, R.id.rela_day_out, R.id.rela_month_out})
    public void onViewClicked(View view) {
        switch (view.getId()) {
            case R.id.imgv_return:
                onBackPressed();
                break;
            case R.id.rela_day_out:
                showPop(2);
                break;
            case R.id.rela_month_out:
                showPop(3);
                break;
        }
    }

    public void showPop(int position) {
        clickPosition = position;
        initPop(position);
        if (popupWindow != null) {
            popupWindow.showAtLocation(llContainer, Gravity.CENTER, 0, 0);
            viewShadow.setVisibility(View.VISIBLE);
        }
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.tv_1: //饼图
                Bundle bundle = new Bundle();
                bundle.putInt("position", clickPosition);
                bundle.putInt("type", 0);
                bundle.putSerializable("bean", bean);
                showActivity(this, DataActivity.class, bundle);
                break;
            case R.id.tv_2: //折线
                Bundle bundle1 = new Bundle();
                bundle1.putInt("position", clickPosition);
                bundle1.putInt("type", 1);
                bundle1.putSerializable("bean", bean);
                showActivity(this, DataActivity.class, bundle1);
                break;
            case R.id.tv_3: //表格
                if (clickPosition == 0) {
                    ToastUtil.showToast(this, "当日消费无表格");
                } else {
                    Bundle bundle2 = new Bundle();
                    bundle2.putInt("position", clickPosition);
                    bundle2.putInt("type", 2);
                    bundle2.putSerializable("bean", bean);
                    showActivity(this, DataActivity.class, bundle2);
                }
                break;
        }
        if(popupWindow!=null){
            popupWindow.dismiss();
        }
    }
}
