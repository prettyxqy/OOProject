package com.app.demo.activitys;

import android.content.ContentValues;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import com.app.demo.R;
import com.app.demo.beans.RemindBean;
import com.app.shop.mylibrary.base.BaseActivity;
import com.app.shop.mylibrary.beans.EventMessage;
import com.app.shop.mylibrary.interfaces.I_itemSelectedListener;
import com.app.shop.mylibrary.utils.ItemChooseUtil;
import com.app.shop.mylibrary.utils.StringUtil;
import com.app.shop.mylibrary.utils.ToastUtil;
import com.app.shop.mylibrary.utils.UserManager;
import com.app.shop.mylibrary.widgts.timepicker.TimePickerCallback;
import com.app.shop.mylibrary.widgts.timepicker.TimePickerUtil;
import com.app.shop.mylibrary.widgts.timepicker.TimePickerView;

import org.litepal.crud.DataSupport;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import de.greenrobot.event.EventBus;

public class AddRemindActivity extends BaseActivity {

    @BindView(R.id.tv_title)
    TextView tvTitle;
    @BindView(R.id.tv_add)
    TextView tvAdd;
    @BindView(R.id.tv_right)
    TextView tvRight;
    @BindView(R.id.tv_time)
    TextView tvTime;
    @BindView(R.id.tv_type)
    TextView tvType;

    RemindBean bean;

    Bundle bundle;

    private List<String> list_type = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_remind);
        ButterKnife.bind(this);
        bundle = getIntent().getExtras();
        tvTitle.setText("提醒");

        bean = (RemindBean) bundle.getSerializable("bean");
        if (bean != null) {
            tvTime.setText(bean.getTime());
            tvType.setText(bean.getPinlv());
        }

        list_type.clear();
        list_type.add("一次");
        list_type.add("每天");
        list_type.add("永不");
    }

    private void save() {

        String time = tvTime.getText().toString();
        String type = tvType.getText().toString();
        if (StringUtil.isEmpty(time) || StringUtil.isEmpty(type)) {
            ToastUtil.showToast(this, "请完善信息");
            return;
        }
        if (bean == null) {
            RemindBean remindBean = new RemindBean();
            remindBean.setRemind_id(System.currentTimeMillis() + "");
            remindBean.setTime(time);
            remindBean.setPinlv(type);
            remindBean.setUser_id(UserManager.getUserId(this));
            remindBean.save();
        } else {
            ContentValues values = new ContentValues();
            values.put("time", time);
            values.put("pinlv", type);
            DataSupport.updateAll(RemindBean.class, values, "remind_id=?", bean.getRemind_id());
        }
        EventBus.getDefault().post(new EventMessage(EventMessage.Refresh));
        onBackPressed();
    }


    @OnClick({R.id.imgv_return, R.id.tv_time, R.id.tv_type, R.id.tv_add})
    public void onViewClicked(View view) {
        switch (view.getId()) {
            case R.id.imgv_return:
                onBackPressed();
                break;
            case R.id.tv_time:
                TimePickerUtil timePickerUtil = new TimePickerUtil();
                timePickerUtil.setDatePicker(this, TimePickerView.Type.HOURS_MINS, null, null, null, new TimePickerCallback() {
                    @Override
                    public void setTimeCallback(int order, int year, int month, int day, int hour, int min, String idcard) {
                        tvTime.setText(hour + ":" + min);
                    }
                });
                timePickerUtil.showTimePicker(0);
                break;
            case R.id.tv_type:
                ItemChooseUtil.showItemWheel(this, list_type, "频次", 0, new I_itemSelectedListener() {
                    @Override
                    public void onItemSelected(int currentPosition) {
                        tvType.setText(list_type.get(currentPosition));
                    }
                });
                break;
            case R.id.tv_add:
                save();
                break;
        }
    }
}
