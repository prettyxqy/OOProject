package com.app.demo.adapters;

import android.view.View;
import android.widget.TextView;

import androidx.annotation.Nullable;

import com.app.demo.R;
import com.app.demo.beans.OrderBean;
import com.app.shop.mylibrary.utils.UserManager;
import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;
import com.facebook.drawee.view.SimpleDraweeView;

import java.util.List;

public class HomeAdapter extends BaseQuickAdapter<OrderBean, HomeAdapter.ViewHolder> {


    public HomeAdapter(int layout, @Nullable List<OrderBean> data) {
        super(layout, data);
    }

    @Override
    protected void convert(ViewHolder holder, OrderBean bean) {
        holder.imgv_face.setActualImageResource(UserManager.getPhoto(mContext));
        holder.tv_name.setText(bean.getTitle());
        holder.tv_money.setText(bean.getMoney());
    }


    public class ViewHolder extends BaseViewHolder {
        SimpleDraweeView imgv_face;
        TextView tv_name;
        TextView tv_money;


        public ViewHolder(View view) {
            super(view);
            imgv_face = view.findViewById(R.id.imgv_list);
            tv_name = view.findViewById(R.id.tv_list_item);
            tv_money = view.findViewById(R.id.tv_money_item);
        }
    }
}
