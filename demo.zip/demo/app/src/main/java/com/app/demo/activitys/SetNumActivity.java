package com.app.demo.activitys;

import android.app.usage.UsageEvents;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import com.app.demo.R;
import com.app.shop.mylibrary.base.BaseActivity;
import com.app.shop.mylibrary.beans.EventMessage;
import com.app.shop.mylibrary.utils.StringUtil;
import com.app.shop.mylibrary.utils.ToastUtil;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import de.greenrobot.event.EventBus;

public class SetNumActivity extends BaseActivity {

    @BindView(R.id.tv_title)
    TextView tvTitle;
    @BindView(R.id.tv_price)
    EditText tvPrice;
    String title;
    String price;
    int position;

    public static void start(Context context, String title, int position, String price) {
        Intent starter = new Intent(context, SetNumActivity.class);
        starter.putExtra("title", title);
        starter.putExtra("position", position);
        starter.putExtra("price", price);
        context.startActivity(starter);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_set_num);
        ButterKnife.bind(this);
        initData();
    }

    private void initData() {

        Intent intent = getIntent();
        title = intent.getStringExtra("title");
        price = intent.getStringExtra("price");
        position = intent.getIntExtra("position", 0);
        tvTitle.setText(title);
        tvPrice.setText(StringUtil.getContent(price));
    }

    @OnClick({R.id.imgv_return, R.id.tv_add})
    public void onViewClicked(View view) {
        switch (view.getId()) {
            case R.id.imgv_return:
                onBackPressed();
                break;
            case R.id.tv_add:
                String num = tvPrice.getText().toString();
                if (StringUtil.isEmpty(num)) {
                    ToastUtil.showToast(this, "请输入金额");
                    return;
                }
                EventBus.getDefault().post(new EventMessage(EventMessage.ADD, num, position));
                onBackPressed();
                break;
        }
    }
}
