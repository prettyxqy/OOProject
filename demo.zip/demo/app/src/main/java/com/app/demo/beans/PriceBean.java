package com.app.demo.beans;

import org.litepal.crud.DataSupport;

import java.io.Serializable;

public class PriceBean extends DataSupport implements Serializable {

    private int id;

    private String p_id;
    private String user_id;
    private String year;
    private String month;
    private String yearIn;
    private String monthIn;


    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getP_id() {
        return p_id;
    }

    public void setP_id(String p_id) {
        this.p_id = p_id;
    }

    public String getUser_id() {
        return user_id;
    }

    public void setUser_id(String user_id) {
        this.user_id = user_id;
    }

    public String getYear() {
        return year;
    }

    public void setYear(String year) {
        this.year = year;
    }

    public String getMonth() {
        return month;
    }

    public void setMonth(String month) {
        this.month = month;
    }

    public String getYearIn() {
        return yearIn;
    }

    public void setYearIn(String yearIn) {
        this.yearIn = yearIn;
    }

    public String getMonthIn() {
        return monthIn;
    }

    public void setMonthIn(String monthIn) {
        this.monthIn = monthIn;
    }
}
