package com.app.demo.activitys;

import android.content.ContentValues;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import com.app.demo.R;
import com.app.demo.beans.PriceBean;
import com.app.shop.mylibrary.base.BaseActivity;
import com.app.shop.mylibrary.beans.EventMessage;
import com.app.shop.mylibrary.utils.StringUtil;
import com.app.shop.mylibrary.utils.UserManager;

import org.litepal.crud.DataSupport;

import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import de.greenrobot.event.EventBus;

public class SetActivity extends BaseActivity {

    @BindView(R.id.tv_title)
    TextView tvTitle;
    @BindView(R.id.tv_right)
    TextView tvRight;
    @BindView(R.id.tv_year)
    TextView tvYear;
    @BindView(R.id.tv_month)
    TextView tvMonth;
    PriceBean bean;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_set);
        ButterKnife.bind(this);
        initData();
    }

    private void initData() {
        tvTitle.setText("设置");
        tvRight.setVisibility(View.VISIBLE);
        tvRight.setText("保存");
        List<PriceBean> list = DataSupport.findAll(PriceBean.class);
        for (int i = 0; i < list.size(); i++) {
            if (list.get(i).getUser_id().equals(UserManager.getUserId(this))) {
                bean = list.get(i);
            }
        }
        if (bean != null) {
            tvYear.setText(StringUtil.getContent(bean.getYear()));
            tvMonth.setText(StringUtil.getContent(bean.getMonth()));
        }
    }

    private void save() {
        String year = tvYear.getText().toString();
        String month = tvMonth.getText().toString();

        if (bean == null) {
            PriceBean priceBean = new PriceBean();
            priceBean.setUser_id(UserManager.getUserId(this));
            priceBean.setP_id(System.currentTimeMillis() + "");
            priceBean.setYear(year);
            priceBean.setMonth(month);
            priceBean.save();
        } else {
            ContentValues values = new ContentValues();
            values.put("year", year);
            values.put("month", month);
            DataSupport.updateAll(PriceBean.class, values, "p_id=?", bean.getP_id());
        }

        EventBus.getDefault().post(new EventMessage(EventMessage.Refresh));
        onBackPressed();
    }

    @Override
    public void onEvent(EventMessage msg) {
        super.onEvent(msg);
        if (msg.getMessageType() == EventMessage.ADD) {
            String price = (String) msg.getmObject();
            int position = msg.getNum();
            if (position == 0) {
                tvYear.setText(price);
            } else if (position == 1) {
                tvMonth.setText(price);
            }
        }
    }

    @OnClick({R.id.imgv_return, R.id.tv_right, R.id.rela_year, R.id.rela_month})
    public void onViewClicked(View view) {
        switch (view.getId()) {
            case R.id.imgv_return:
                onBackPressed();
                break;
            case R.id.tv_right:
                save();
                break;
            case R.id.rela_year:
                SetNumActivity.start(this, "设置年度消费预算", 0, tvYear.getText().toString());
                break;
            case R.id.rela_month:
                SetNumActivity.start(this, "调整本月消费预算", 1, tvMonth.getText().toString());
                break;
        }
    }

}
