package com.app.demo.beans;

import org.litepal.crud.DataSupport;

import java.io.Serializable;

public class ExcelBean extends DataSupport implements Serializable {

    private int id;

    private String name;
    private String num;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getNum() {
        return num;
    }

    public void setNum(String num) {
        this.num = num;
    }
}
