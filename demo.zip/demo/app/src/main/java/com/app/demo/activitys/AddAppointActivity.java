package com.app.demo.activitys;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import com.app.demo.R;
import com.app.demo.beans.OrderBean;
import com.app.shop.mylibrary.base.BaseActivity;
import com.app.shop.mylibrary.beans.EventMessage;
import com.app.shop.mylibrary.interfaces.I_itemSelectedListener;
import com.app.shop.mylibrary.utils.ItemChooseUtil;
import com.app.shop.mylibrary.utils.StringUtil;
import com.app.shop.mylibrary.utils.TimeUtil;
import com.app.shop.mylibrary.utils.ToastUtil;
import com.app.shop.mylibrary.utils.UserManager;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import de.greenrobot.event.EventBus;

public class AddAppointActivity extends BaseActivity {


    @BindView(R.id.tv_title)
    TextView tvTitle;
    @BindView(R.id.edt_title)
    EditText edtTitle;
    @BindView(R.id.tv_price)
    EditText edtPrice;
    @BindView(R.id.tv_type)
    TextView tvType;

    private List<String> list_type = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_income);
        ButterKnife.bind(this);
        tvTitle.setText("添加");
        initData();
    }

    private void initData() {
        list_type.add("支出");
        list_type.add("收入");
    }

    private void add() {
        String type = tvType.getText().toString();
        String title = edtTitle.getText().toString();
        String price = edtPrice.getText().toString();


        if (StringUtil.isEmpty(type) || StringUtil.isEmpty(title) || StringUtil.isEmpty(price)) {
            ToastUtil.showToast(this, "请完善信息");
            return;
        }

        OrderBean bean = new OrderBean();
        bean.setOrder_id(System.currentTimeMillis() + "");
        bean.setUser(UserManager.getUserName(this));
        bean.setUser_id(UserManager.getUserId(this));
        bean.setCreate_time(TimeUtil.getTodayData("yyyy-MM-dd HH:mm:ss"));
        bean.setTime(TimeUtil.getTodayData("yyyy-MM-dd"));
        bean.setMoney(price);
        bean.setTitle(title);
        bean.setType(type);
        bean.save();
        EventBus.getDefault().post(new EventMessage(EventMessage.Refresh));
        onBackPressed();
    }


    @OnClick({R.id.imgv_return, R.id.tv_type, R.id.tv_add})
    public void onViewClicked(View view) {
        switch (view.getId()) {

            case R.id.tv_type:
                ItemChooseUtil.showItemWheel(this, list_type, "类型", 0, new I_itemSelectedListener() {
                    @Override
                    public void onItemSelected(int currentPosition) {
                        tvType.setText(list_type.get(currentPosition));
                    }
                });
                break;
            case R.id.imgv_return:
                onBackPressed();
                break;

            case R.id.tv_add:
                add();
                break;
        }
    }

}
