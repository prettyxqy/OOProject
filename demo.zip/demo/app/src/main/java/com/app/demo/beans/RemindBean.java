package com.app.demo.beans;

import org.litepal.crud.DataSupport;

import java.io.Serializable;

public class RemindBean extends DataSupport implements Serializable {

    private int id;

    private String remind_id;
    private String user_id;
    private String time;
    private String pinlv;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getRemind_id() {
        return remind_id;
    }

    public void setRemind_id(String remind_id) {
        this.remind_id = remind_id;
    }

    public String getUser_id() {
        return user_id;
    }

    public void setUser_id(String user_id) {
        this.user_id = user_id;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getPinlv() {
        return pinlv;
    }

    public void setPinlv(String pinlv) {
        this.pinlv = pinlv;
    }
}
