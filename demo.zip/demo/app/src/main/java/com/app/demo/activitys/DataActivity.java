package com.app.demo.activitys;

import android.graphics.Color;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.app.demo.R;
import com.app.demo.adapters.ExcelAdapter;
import com.app.demo.beans.ExcelBean;
import com.app.demo.beans.LineBean;
import com.app.demo.beans.OrderBean;
import com.app.demo.beans.PieBean;
import com.app.demo.beans.PriceBean;
import com.app.shop.mylibrary.base.BaseActivity;
import com.app.shop.mylibrary.utils.TimeUtil;
import com.app.shop.mylibrary.widgts.PieChartView;
import com.github.mikephil.charting.charts.LineChart;
import com.github.mikephil.charting.components.AxisBase;
import com.github.mikephil.charting.components.Description;
import com.github.mikephil.charting.components.Legend;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.components.YAxis;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.LineData;
import com.github.mikephil.charting.data.LineDataSet;
import com.github.mikephil.charting.formatter.IAxisValueFormatter;
import com.github.mikephil.charting.formatter.IValueFormatter;
import com.github.mikephil.charting.utils.ViewPortHandler;

import org.litepal.LitePal;
import org.litepal.crud.DataSupport;

import java.nio.BufferUnderflowException;
import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;

public class DataActivity extends BaseActivity {

    @BindView(R.id.tv_title)
    TextView tvTitle;
    @BindView(R.id.tv_num)
    TextView tvNum;
    @BindView(R.id.tv_num_year)
    TextView tvNumYear;
    @BindView(R.id.tv_num_month)
    TextView tvNumMonth;
    @BindView(R.id.pie_chart)
    PieChartView pieChart;
    @BindView(R.id.ll_pie)
    LinearLayout llPie;
    @BindView(R.id.chartview)
    LineChart chart;
    @BindView(R.id.ll_line)
    LinearLayout llLine;
    @BindView(R.id.recy)
    RecyclerView recy;
    int type;
    int position;
    XAxis xAxis; //x轴
    YAxis leftYAxis; //y轴
    YAxis rightYaxis;
    List<LineBean> list = new ArrayList<>();
    List<OrderBean> list_data = new ArrayList<>();
    PriceBean bean;
    String year_now, month_now, day_now;
    int num_max = 0;
    int month_money = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_data);
        ButterKnife.bind(this);
        tvTitle.setText("我的钱包");
        initData();
    }

    private void initData() {
        list_data.clear();
        list_data = DataSupport.findAll(OrderBean.class);
        Bundle bundle = getIntent().getExtras();
        type = bundle.getInt("type");
        position = bundle.getInt("position");
        bean = (PriceBean) bundle.getSerializable("bean");

        year_now = TimeUtil.getTodayData("yyyy");
        month_now = TimeUtil.getTodayData("yyyy-MM");
        day_now = TimeUtil.getTodayData("yyyy-MM-dd");

        if (bean != null) {
            tvNumYear.setText(bean.getYear());
            tvNumMonth.setText(bean.getMonth());
            month_money = Integer.parseInt(bean.getMonth());
        }

        if (type == 0) {
            llPie.setVisibility(View.VISIBLE);
            llLine.setVisibility(View.GONE);
            recy.setVisibility(View.GONE);
            initPieChart();
        } else if (type == 1) {
            llPie.setVisibility(View.GONE);
            llLine.setVisibility(View.VISIBLE);
            recy.setVisibility(View.GONE);
            initLine();
        } else if (type == 2) {
            llPie.setVisibility(View.GONE);
            llLine.setVisibility(View.GONE);
            recy.setVisibility(View.VISIBLE);
            initRecy();
        }
    }

    private void initRecy() {

        List<String> list_time = new ArrayList<>();
        List<String> list_money = new ArrayList<>();

        List<ExcelBean> list = new ArrayList<>();
        if (list_data.size() > 0) {
            ExcelBean bean = new ExcelBean();
            bean.setName("时间");
            bean.setNum("消费金额");
            list.add(bean);
        }
//        if (position == 1) {
//            for (int i = 0; i < list_data.size(); i++) {
//                if (list_data.get(i).getTime().contains(month_now) && list_data.get(i).getType().equals("支出")) {
//                    ExcelBean bean = new ExcelBean();
//                    bean.setName(list_data.get(i).getTime());
//                    bean.setNum(list_data.get(i).getMoney());
//                    list.add(bean);
//                }
//            }
//
//        } else
        if (position == 2) {
            for (int i = 0; i < list_data.size(); i++) {
                if (list_data.get(i).getTime().contains(year_now) && list_data.get(i).getType().equals("支出")) {
                    ExcelBean bean = new ExcelBean();
                    bean.setName(list_data.get(i).getTime());
                    bean.setNum(list_data.get(i).getMoney());
                    list.add(bean);
                }
            }

        } else if (position == 3) {


            for (int i = 0; i < list_data.size(); i++) {
                if (list_data.get(i).getTime().contains(year_now) && list_data.get(i).getType().equals("支出")) {
                    if (!list_time.contains(list_data.get(i).getTime())) {
                        list_time.add(list_data.get(i).getTime());
                    }
                }

            }
            int num = 0;
            for (int i = 0; i < list_time.size(); i++) {
                for (int j = 0; j < list_data.size(); j++) {
                    if (list_time.get(i).equals(list_data.get(j).getTime()) && list_data.get(j).getType().equals("支出")) {
                        num += Integer.parseInt(list_data.get(j).getMoney());
                    }
                }

                if (num_max <= num) {
                    num_max = num;
                }

                list_money.add(num + "");
            }


            for (int i = 0; i < list_time.size(); i++) {
                ExcelBean bean = new ExcelBean();
                bean.setName(list_time.get(i).substring(0, 7));
                bean.setNum(list_money.get(i));
                list.add(bean);
            }


//            for (int i = 0; i < list_data.size(); i++) {
//                if (list_data.get(i).getTime().contains(year_now) && list_data.get(i).getType().equals("支出")) {
//                    ExcelBean bean = new ExcelBean();
//                    bean.setName(list_data.get(i).getTime());
//                    bean.setNum(list_data.get(i).getMoney());
//                    list.add(bean);
//                }
//            }
        }


        ExcelAdapter adapter = new ExcelAdapter(R.layout.item_excel, list);
        adapter.setEmptyView(LayoutInflater.from(this).inflate(R.layout.view_list_empty, null));
        recy.setLayoutManager(new LinearLayoutManager(this));
        recy.setAdapter(adapter);
    }

    private void initLine() {

        List<LineBean> list = new ArrayList<>();
//        if (position == 0) { //本日
//            for (int i = 0; i < list_data.size(); i++) {
//                if (list_data.get(i).getTime().contains(day_now) && list_data.get(i).getType().equals("支出")) {
//                    LineBean bean = new LineBean();
//                    bean.setName(list_data.get(i).getTime());
//                    bean.setNum(Integer.parseInt(list_data.get(i).getMoney()));
//                    list.add(bean);
//                }
//            }
//
//        } else if (position == 1) { //本月
//            for (int i = 0; i < list_data.size(); i++) {
//                if (list_data.get(i).getTime().contains(month_now) && list_data.get(i).getType().equals("支出")) {
//                    LineBean bean = new LineBean();
//                    bean.setName(list_data.get(i).getTime());
//                    bean.setNum(Integer.parseInt(list_data.get(i).getMoney()));
//                    list.add(bean);
//                }
//            }
//
//        } else

        List<String> list_time = new ArrayList<>();
        List<String> list_money = new ArrayList<>();


        if (position == 2) {

            LineBean l = new LineBean();
            l.setName("0");
            l.setNum(0);
            list.add(l);


            for (int i = 0; i < list_data.size(); i++) {
                if (list_data.get(i).getTime().equals(day_now) && list_data.get(i).getType().equals("支出")) {
                    LineBean bean = new LineBean();
                    bean.setName(list_data.get(i).getTitle());
                    bean.setNum(Integer.parseInt(list_data.get(i).getMoney()));
                    list.add(bean);

                    if (num_max < Integer.parseInt(list_data.get(i).getMoney())) {
                        num_max = Integer.parseInt(list_data.get(i).getMoney());
                    }
                }
            }

        } else if (position == 3) {
            for (int i = 0; i < list_data.size(); i++) {
                if (list_data.get(i).getTime().contains(year_now) && list_data.get(i).getType().equals("支出")) {
                    if (!list_time.contains(list_data.get(i).getTime())) {
                        list_time.add(list_data.get(i).getTime());
                    }
                }

            }
            int num = 0;
            for (int i = 0; i < list_time.size(); i++) {
                for (int j = 0; j < list_data.size(); j++) {
                    if (list_time.get(i).equals(list_data.get(j).getTime()) && list_data.get(j).getType().equals("支出")) {
                        num += Integer.parseInt(list_data.get(j).getMoney());
                    }
                }

                if (num_max <= num) {
                    num_max = num;
                }

                list_money.add(num + "");
            }


            LineBean l = new LineBean();
            l.setName("0");
            l.setNum(0);
            list.add(l);
            for (int i = 0; i < list_time.size(); i++) {
                LineBean bean = new LineBean();
                bean.setName(list_time.get(i));
                bean.setNum(Integer.parseInt(list_money.get(i)));
                list.add(bean);
            }

        }
        initChart();
        if (list.size() > 0) {
            showLineChart(list, "消费", getResources().getColor(R.color.color_3853e8));
        }
    }

    /**
     * 展示曲线
     *
     * @param dataList 数据集合
     * @param name     曲线名称
     * @param color    曲线颜色
     */
    public void showLineChart(final List<LineBean> dataList, String name, int color) {

        //自定义x轴显示元素
        xAxis.setValueFormatter(new IAxisValueFormatter() {
            @Override
            public String getFormattedValue(float value, AxisBase axis) {
                int position = (int) value;
//                return getTime((int) value);
                if (position >= 0 && position < dataList.size()) {
                    return dataList.get(position).getName();
                } else {
                    return "0";
                }
            }
        });

//        //自定义y轴显示元素 ，
        leftYAxis.setValueFormatter(new IAxisValueFormatter() {
            @Override
            public String getFormattedValue(float value, AxisBase axis) {
                return (int) value + "";
            }
        });

        List<Entry> entries = new ArrayList<>();
        for (int i = 0; i < dataList.size(); i++) {
            LineBean data = dataList.get(i);
            Entry entry = new Entry(i, (float) data.getNum());
            entries.add(entry);
        }
        // 每一个LineDataSet代表一条线
        LineDataSet lineDataSet = new LineDataSet(entries, name);
        //设置线的属性
        initLineDataSet(lineDataSet, color, LineDataSet.Mode.LINEAR);
        //设置数据
        LineData lineData = new LineData(lineDataSet);
        if (lineData != null) {

            chart.setData(lineData);
        }
    }

    /**
     * 曲线初始化设置 一个LineDataSet 代表一条曲线
     *
     * @param lineDataSet 线条
     * @param color       线条颜色
     * @param mode
     */
    private void initLineDataSet(LineDataSet lineDataSet, int color, LineDataSet.Mode mode) {
        lineDataSet.setColor(color);
        lineDataSet.setCircleColor(color);
        lineDataSet.setLineWidth(2f);
        lineDataSet.setCircleRadius(3f);
        //设置曲线值的圆点是实心还是空心
        lineDataSet.setDrawCircleHole(false);
        lineDataSet.setValueTextSize(10f);
        //设置折线图填充
        lineDataSet.setDrawFilled(true);
        lineDataSet.setFillColor(color);
        lineDataSet.setFillAlpha(25);
        lineDataSet.setFormLineWidth(1f);
        lineDataSet.setFormSize(15.f);
        //显示点
        lineDataSet.setDrawCircles(true);
        //显示内容
        lineDataSet.setDrawValues(true);
        //自定义显示的点的内容
        lineDataSet.setValueFormatter(new IValueFormatter() {
            @Override
            public String getFormattedValue(float value, Entry entry, int dataSetIndex, ViewPortHandler viewPortHandler) {
//                DecimalFormat df = new DecimalFormat(".00");
//                return df.format(value * 100) + "%";
                return (int) value + "";
            }
        });
        LineData data = new LineData(lineDataSet);
        data.setValueTextColor(Color.BLACK); //数据颜色
        data.setValueTextSize(10f);
        if (mode == null) {
            //设置曲线展示为圆滑曲线（如果不设置则默认折线）
            lineDataSet.setMode(LineDataSet.Mode.LINEAR);
        } else {
            lineDataSet.setMode(mode);
        }
    }


    private void initChart() {
        //是否展示网格线
        chart.setDrawGridBackground(false);
        //是否显示边界
        chart.setDrawBorders(false);
        //是否可以拖动
        chart.setDragEnabled(false);
        //是否有触摸事件
        chart.setTouchEnabled(false);
        //两指放大缩小
        chart.setPinchZoom(false);
        //x轴动画
        chart.animateX(200);
        //无数据时展示
        chart.setNoDataText("暂无数据");
        //背景色
        chart.setBackgroundColor(Color.parseColor("#ffffff"));
        //表格右下角的小标签隐藏
        Description description = new Description();
        description.setEnabled(false);
        chart.setDescription(description);

        xAxis = chart.getXAxis(); //x轴
        leftYAxis = chart.getAxisLeft(); //y轴
        rightYaxis = chart.getAxisRight();

//        xAxis.setTextSize(13);
//        xAxis.setTextColor(Color.parseColor("#999999"));
//        xAxis.setDrawGridLines(false); //是否显示网格
//        xAxis.setAxisLineColor(Color.parseColor("#f2f2f2"));
//        xAxis.setDrawAxisLine(true);
        xAxis.setPosition(XAxis.XAxisPosition.BOTTOM);//设置在底部
        xAxis.setAxisMinimum(0f);
        xAxis.setGranularity(1f);
        //设置X轴分割数量
//        xAxis.setLabelCount(6, false);

        //保证Y轴从0开始，不然会上移一点
//        leftYAxis.setAxisLineColor(Color.parseColor("#00ffffff"));// 坐标轴颜色，设置为透明
//        leftYAxis.setTextColor(Color.parseColor("#00ffffff")); //坐标轴数值
        leftYAxis.setGridColor(Color.parseColor("#f2f2f2"));    // 横着的 网格线颜色，默认GRAY
        leftYAxis.setGridLineWidth(1);
        leftYAxis.setAxisMinimum(0f);
        leftYAxis.setDrawGridLines(true);//坐标线
        leftYAxis.setLabelCount(8); //设置y轴分割数量
        leftYAxis.setAxisMaximum(num_max);
        //去除右侧Y轴
        rightYaxis.setEnabled(false);
        rightYaxis.setAxisMinimum(0f);
        rightYaxis.setDrawGridLines(false);

        /***折线图例 标签 设置***/
        Legend legend = chart.getLegend(); //图例
        // 设置显示类型，LINE CIRCLE SQUARE EMPTY 等等 多种方式，查看LegendForm
        legend.setEnabled(true);// 是否绘制图例
        legend.setForm(Legend.LegendForm.LINE); //左下角表格名称前面的小标志
        legend.setTextSize(11f);
//        legend.setTextColor(Color.parseColor("#00ffffff")); //左下角表格名称
//        legend.setYEntrySpace(20);  // 设置垂直图例间间距，默认0
        //显示位置 左下方
        legend.setVerticalAlignment(Legend.LegendVerticalAlignment.BOTTOM);
        legend.setHorizontalAlignment(Legend.LegendHorizontalAlignment.LEFT);
        legend.setOrientation(Legend.LegendOrientation.HORIZONTAL);
        //是否绘制在图表里面
        legend.setDrawInside(false);
    }

    private void initPieChart() {

        List<PieBean> list = new ArrayList<>();
//        if (position == 0) { //本日
//            for (int i = 0; i < list_data.size(); i++) {
//                if (list_data.get(i).getTime().contains(day_now) && list_data.get(i).getType().equals("支出")) {
//                    PieBean bean = new PieBean();
//                    bean.setName(list_data.get(i).getTime());
//                    bean.setNum(Integer.parseInt(list_data.get(i).getMoney()));
//                    list.add(bean);
//                }
//            }
//
//        } else if (position == 1) { //本月
//            for (int i = 0; i < list_data.size(); i++) {
//                if (list_data.get(i).getTime().contains(month_now) && list_data.get(i).getType().equals("支出")) {
//                    PieBean bean = new PieBean();
//                    bean.setName(list_data.get(i).getTime());
//                    bean.setNum(Integer.parseInt(list_data.get(i).getMoney()));
//                    list.add(bean);
//                }
//            }
//
//        } else
        if (position == 2) { //全年
            for (int i = 0; i < list_data.size(); i++) {
                if (list_data.get(i).getTime().contains(year_now) && list_data.get(i).getType().equals("支出")) {
                    PieBean bean = new PieBean();
                    bean.setName(list_data.get(i).getTime());
                    bean.setNum(Integer.parseInt(list_data.get(i).getMoney()));
                    list.add(bean);
                }
            }

        } else if (position == 3) {
            for (int i = 0; i < list_data.size(); i++) {
                if (list_data.get(i).getTime().contains(year_now) && list_data.get(i).getType().equals("支出")) {
                    PieBean bean = new PieBean();
                    bean.setName(list_data.get(i).getTime());
                    bean.setNum(Integer.parseInt(list_data.get(i).getMoney()));
                    list.add(bean);
                }
            }
        }


        List<PieBean> list_c = new ArrayList<>();

        int total = 0;
//        if (position == 0) { //本日
//            for (int i = 0; i < list.size(); i++) {
//
//                if (list.get(i).getName().equals(day_now)) {
//                    total += list.get(i).getNum();
//                }
//            }
//
//            PieBean bean1 = new PieBean();
//            bean1.setName("已消费金额");
//            bean1.setNum(total);
//            PieBean bean2 = new PieBean();
//            bean2.setName("未消费金额");
//            bean2.setNum(0);
//            list_c.add(bean1);
//            list_c.add(bean2);
//        } else if (position == 1) {
//            for (int i = 0; i < list.size(); i++) {
//
//                if (list.get(i).getName().contains(month_now)) {
//                    total += list.get(i).getNum();
//                }
//            }
//
//            PieBean bean1 = new PieBean();
//            bean1.setName("已消费金额");
//            bean1.setNum(total);
//            PieBean bean2 = new PieBean();
//            bean2.setName("未消费金额");
//            if (Integer.parseInt(bean.getMonth()) - total > 0) {
//                bean2.setNum(Integer.parseInt(bean.getMonth()) - total);
//            } else {
//                bean2.setNum(0);
//            }
//
//            list_c.add(bean1);
//            list_c.add(bean2);
//        } else
        if (position == 2) {
            for (int i = 0; i < list.size(); i++) {

                if (list.get(i).getName().equals(day_now)) {
                    total += list.get(i).getNum();
                }
            }

            PieBean bean1 = new PieBean();
            PieBean bean2 = new PieBean();
            bean1.setNum(total);
            int num = 0;

            if (month_money - total > 0) {
                num = month_money - total;
            }
            bean1.setName("已消费金额" + total);
            bean2.setName("未消费金额" + num);
            bean2.setNum(num);
            list_c.add(bean1);
            list_c.add(bean2);
        } else if (position == 3) {
            for (int i = 0; i < list.size(); i++) {

                if (list.get(i).getName().contains(month_now)) {
                    total += list.get(i).getNum();
                }
            }

            PieBean bean1 = new PieBean();
            PieBean bean2 = new PieBean();
            bean1.setNum(total);
            int num = 0;
            if (month_money - total > 0) {
                num = month_money - total;
            }
            bean2.setNum(num);
            bean1.setName("已消费金额" + total);
            bean2.setName("未消费金额" + num);
            list_c.add(bean1);
            list_c.add(bean2);
        }

        List<PieChartView.PieceDataHolder> pieceDataHolders = new ArrayList<>();

        for (int i = 0; i < list_c.size(); i++) {
            int color = R.color.color_3853e8;
            if (i == 0) {
                color = R.color.colorAccent;
            } else {
                color = R.color.color_3853e8;
            }
            pieceDataHolders.add(new PieChartView.PieceDataHolder(list_c.get(i).getNum(), getResources().getColor(color), list_c.get(i).getName()));
        }
        pieChart.setData(pieceDataHolders);
    }

    @OnClick(R.id.imgv_return)
    public void onViewClicked() {
        onBackPressed();
    }
}
