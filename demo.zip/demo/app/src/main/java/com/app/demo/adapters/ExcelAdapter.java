package com.app.demo.adapters;

import android.view.View;
import android.widget.TextView;

import androidx.annotation.Nullable;

import com.app.demo.R;
import com.app.demo.beans.ExcelBean;
import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;

import java.util.List;

public class ExcelAdapter extends BaseQuickAdapter<ExcelBean, ExcelAdapter.ViewHolder> {


    public ExcelAdapter(int layout, @Nullable List<ExcelBean> data) {
        super(layout, data);
    }

    @Override
    protected void convert(ViewHolder holder, ExcelBean bean) {

        holder.tv_name.setText(bean.getName());
        holder.tv_num.setText(bean.getNum());

    }


    public class ViewHolder extends BaseViewHolder {
        TextView tv_name;
        TextView tv_num;


        public ViewHolder(View view) {
            super(view);
            tv_name = view.findViewById(R.id.tv_name_item);
            tv_num = view.findViewById(R.id.tv_num_item);

        }
    }
}
