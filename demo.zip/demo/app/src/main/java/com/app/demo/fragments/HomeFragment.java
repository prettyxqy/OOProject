package com.app.demo.fragments;


import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.app.demo.R;
import com.app.demo.activitys.AddAppointActivity;
import com.app.demo.adapters.HomeAdapter;
import com.app.demo.beans.OrderBean;
import com.app.shop.mylibrary.base.BaseFragment;
import com.app.shop.mylibrary.beans.EventMessage;
import com.app.shop.mylibrary.utils.TimeUtil;

import org.litepal.LitePal;
import org.litepal.crud.DataSupport;

import java.lang.invoke.CallSite;
import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;


/**
 * A simple {@link Fragment} subclass.
 */
public class HomeFragment extends BaseFragment {


    @BindView(R.id.imgv_return)
    ImageView imgvReturn;
    @BindView(R.id.tv_title)
    TextView tvTitle;
    @BindView(R.id.tv_right)
    TextView tvRight;
    @BindView(R.id.recy)
    RecyclerView recy;
    @BindView(R.id.tv_message)
    TextView tvMessage;
    private List<OrderBean> list = new ArrayList<>();
    private HomeAdapter adapter;


    public HomeFragment() {
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_home, container, false);
        ButterKnife.bind(this, view);
        registerEventBus();
        imgvReturn.setVisibility(View.GONE);
        tvTitle.setText("主页");
        tvRight.setVisibility(View.VISIBLE);
        tvRight.setText("添加");
        initList();
        return view;
    }

    //列表
    private void initList() {
        list.clear();
        list = DataSupport.findAll(OrderBean.class);
        adapter = new HomeAdapter(R.layout.item_home, list);
        adapter.setEmptyView(LayoutInflater.from(getActivity()).inflate(R.layout.view_list_empty, null));
        recy.setLayoutManager(new LinearLayoutManager(getActivity()));
        recy.setAdapter(adapter);

        int total_in = 0;
        int total_out = 0;
        for (int i = 0; i < list.size(); i++) {
            if (list.get(i).getType().equals("收入")) {
                total_in += Integer.parseInt(list.get(i).getMoney());
            } else {
                total_out += Integer.parseInt(list.get(i).getMoney());
            }

        }
        tvMessage.setText(TimeUtil.getTodayData("MM") + "月 收" + total_in + "/支 " + total_out);
    }

    @Override
    public void onEvent(EventMessage msg) {
        super.onEvent(msg);
        if (msg.getMessageType() == EventMessage.Refresh) {
            initList();
        }
    }

    @OnClick(R.id.tv_right)
    public void onViewClicked() {
        skipActivity(getActivity(), AddAppointActivity.class);
    }
}
