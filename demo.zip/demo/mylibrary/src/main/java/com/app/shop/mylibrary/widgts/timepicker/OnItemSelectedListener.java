package com.app.shop.mylibrary.widgts.timepicker;


public interface OnItemSelectedListener {
    void onItemSelected(int index);
}
