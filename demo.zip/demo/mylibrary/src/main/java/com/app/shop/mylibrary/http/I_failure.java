package com.app.shop.mylibrary.http;

/**
 * Created by seven on 2016/5/21.
 */
public interface I_failure {
    void doFailure();
}
