package com.app.shop.mylibrary.widgts.timepicker;

/**
 * Create by alex on 2019-12-23
 * desc:
 */
public interface OptionSelectistener {
    void onSelect(int p);
}
