package com.app.shop.mylibrary.interfaces;

/**
 * Created by seven on 2017/6/7.
 */

public interface I_NumChangeListener {
    void onNumAddListener(int num);
    void onNumSubtractListener(int num);
}
