package com.app.shop.mylibrary.widgts.timepicker;

/**
 * Created by wsg on 17/5/16.
 */

public interface TimePickerCallback {
   void setTimeCallback(int order, int year, int month, int day, int hour, int min, String idcard);
}
