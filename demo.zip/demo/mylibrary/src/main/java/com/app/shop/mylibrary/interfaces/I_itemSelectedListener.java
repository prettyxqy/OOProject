package com.app.shop.mylibrary.interfaces;

/**
 * Created by seven on 2017/2/22.
 */

public interface I_itemSelectedListener {
    void onItemSelected(int currentPosition);
}
