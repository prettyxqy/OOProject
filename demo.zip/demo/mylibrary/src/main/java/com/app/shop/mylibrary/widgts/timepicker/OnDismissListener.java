package com.app.shop.mylibrary.widgts.timepicker;

/**
 * Created by Sai on 15/8/9.
 */
public interface OnDismissListener {
    void onDismiss(Object o);
}
