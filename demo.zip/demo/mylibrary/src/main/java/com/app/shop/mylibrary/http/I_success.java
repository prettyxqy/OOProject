package com.app.shop.mylibrary.http;

import org.json.JSONException;

/**
 * Created by seven on 2016/5/21.
 */
public interface I_success {
    void doSuccess(String t) throws JSONException;
}
