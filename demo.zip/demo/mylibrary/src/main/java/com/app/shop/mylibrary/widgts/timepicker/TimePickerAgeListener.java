package com.app.shop.mylibrary.widgts.timepicker;

/**
 * Created by yangshenghui on 2017/11/20.
 */

public interface TimePickerAgeListener {

    void onSelect(int age);
}
