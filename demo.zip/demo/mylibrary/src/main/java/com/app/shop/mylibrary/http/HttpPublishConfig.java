package com.app.shop.mylibrary.http;



import com.app.shop.mylibrary.MyApplication;
import com.app.shop.mylibrary.utils.SharedPreferencesUtil;

import java.util.Map;

/**
 * @titile 网络请求的公共参数
 * @desc Created by seven on 2018/1/18.
 */

public class HttpPublishConfig {
    public static void setPublicParam(Map map) {
        //这里封装公共参数
//        map.put("","");
    }
}
